# PRODIGY_INFOTECH_DS_Task3
The provided code demonstrates the implementation of a decision tree classifier in Python using scikit-learn.
It involves loading and preprocessing the data, training the classifier, making predictions, evaluating accuracy, and visualizing the decision tree.
Additionally, it showcases the application of pruning techniques for optimizing the decision tree's performance.
